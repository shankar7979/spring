package collection;

import java.util.HashSet;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;


public class Test5 {

	public static void main(String[] args) {
		
		HashSet<String>  s=new HashSet<>();
 
		
		
	}
}
