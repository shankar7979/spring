
public class Test3 {

	public static void main(String[] args) {
		
		int x=100;
		int y=200;
		
		if(x++>=110 & y++>200){
			System.out.println("it's right");
		}
		else
			System.out.println("not correct");
		
		System.out.println(x+"   "+y);
		
	}
}
