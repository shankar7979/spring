package regex;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Ex3 {

	public static void main(String[] args) {
	
	String var="hello world";
	System.out.println(var.matches("^hello"));
	
		
	}
}
