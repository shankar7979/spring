import static  java.lang.System.out;
import static  java.lang.Math.PI;

public class Test8 {

	public static void main(String[] args) {
	    out.println("PI is "+PI);
		
		
	}
}
