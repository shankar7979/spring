import java.util.TreeSet;

public class Test7 {

	public static void main(String[] args) {
		TreeSet  set1 = new TreeSet();
		
		set1.add(8778);
		set1.add(89);
		set1.add(77);
		set1.add(87);
		set1.add(78);
		
		set1.add("hello");
		
		System.out.println(set1);
	}
}
