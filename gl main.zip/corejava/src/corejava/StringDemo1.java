package corejava;

public class StringDemo1 {
public static void main(String[] args) {
	
	String var1="hello";
	
	System.out.println(var1);
	
	var1=var1.concat(" world");
	
	System.out.println(var1);
	
}
}
