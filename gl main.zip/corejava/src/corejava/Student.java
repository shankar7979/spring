package corejava;

public class Student {

	final String country;
	
	public Student() {
	
	}
	
	
	
	
}
