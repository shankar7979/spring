package corejava;

public class forLoop1 {

	public static void main(String[] args) {
		
		for (int i = 1, j=5; i <=10; i++,j++) {
			
			System.out.println(i+"  "+j);
			
		}
	}
}
