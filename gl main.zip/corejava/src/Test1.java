
public class Test1 {

	public static void main(String[] args) {
		
		int x;
		int _x;
	
		int $x;
		
		/*int %x;
        String &name;
        
        String name%;
		
        String 1name;*/
		
		byte b=-128;
		
		short y=-129;
	
		short y1=32767;
		
		//short y2=32768;
		
	System.out.println(Byte.MAX_VALUE);	//127
	System.out.println(Byte.MIN_VALUE);//-128
	
	System.out.println(Short.MAX_VALUE);	//32767
	System.out.println(Short.MIN_VALUE);//-32768
	
	
	System.out.println(Integer.MAX_VALUE);	//2147483647
	System.out.println(Integer.MIN_VALUE);//-2147483648
	
	int p1=2147483647;
	
	long p2=2147483648l;
	
	
	}
}
