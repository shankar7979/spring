public class Hello {

	public static void main(String[] args) {
		System.out.println("hello world");
		// sysout ctrl + space
		System.out.println("we are learning java program");

		int a = 10;
		int b = 20;
		int c = a + b;

		System.out.println("no1 is " + a);
		System.out.println("no2 is " + b);
		System.out.println("sum  is " + c);

//		System.out.println("no1 is " + a + "\nno2 is " + b + "\nsum is " + c);

		System.out.printf("no1 is %d\nno2 is %d\nsum is%d",a,b,c);
	}
}

class Welcome {

	public static void main(String[] args) {
		System.out.println("This is welcome class ");
		double p=90.55;
		float p1=78.678F;
		
		float radius=7.8f, area,circumference;
		
		
		
		
		
		
	}
}
