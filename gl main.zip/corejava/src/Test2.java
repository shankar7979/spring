import java.util.Date;

public class Test2 {
public static void main(String[] args) {
	
	byte s1=127;
	
	byte  s2=(byte) 130;
	
	System.out.println(s2);
	
	int y=2147483647;
	
	long  y1=2147483648l;
	
	int x;
	
	System.out.println(y1);
//	System.out.println(x);
	
String $name,DEFAULT_VAL;


Date date1=new Date();

int k=10;



}
}
