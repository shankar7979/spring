
public class ShiftOperator {

	public static void main(String[] args) {
		
		int x=100;
		
		System.out.println(x);//‭01100100‬
		System.out.println(x<<1);//‭11001000
		System.out.println(x<<2);//‭000110010000‬
		
		System.out.println(x>>2);//‭00011001‬
			
	}
}
