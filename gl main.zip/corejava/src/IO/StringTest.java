package IO;

public class StringTest {

	public static void main(String[] args) {
		String var="The quick brown fox jumps over the lazy dog";
		
		String ar[]=var.split("fox");
		
		System.out.println(var.indexOf("a"));
		System.out.println(var.lastIndexOf("e"));
		
		
		
	}
}
