
public class EmployeeMaIN {
	 
	public static void main(String[] args) {
		 Employee employee=new Employee();
		
		System.out.println("Id is "+employee.id);
		System.out.println("Name is "+employee.name);
		System.out.println("Salary is "+employee.salary);
		
		System.out.println("company_name "+Employee.company_name);
		System.out.println("country "+Employee.country);
		
		System.out.println(Math.PI);
		System.out.println(Math.E);
		
		System.out.println("sin 90  is   "+Math.sin(Math.PI/2));

		System.out.println(Math.pow(4, 3));
		
		
	}
}
