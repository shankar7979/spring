
public class Casting {

	public static void main(String[] args) {
		
		int x=100;
		float p=x;// implicit casting
		
		System.out.println(x+"   "+p);
		
		int y=300;
		byte p1=(byte) y;// explicit casting
		
		System.out.println(y+"   "+p1);
		
		
	}
}
