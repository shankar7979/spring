package org.com;

public class Server {

}
