
document.write("hello to javascript")
var a=10
b=20;
c=a+b

document.write("<br>No1 is "+a)
document.write("<br>No2 is "+b)
document.write("<br>Sum is "+c)

alert("no1 is "+a)
alert("no2 is "+b)
alert("sum is "+c)
