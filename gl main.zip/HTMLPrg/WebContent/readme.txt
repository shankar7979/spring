color code 
  red
  green
  hard pink
  blue
  
 function 
     rgb(0,0,0)
     range 0 -255
     
     Hexadecimal color 
     start with #
     total 7 char including #
     after # 0-9 a-f A-F
     
     
     <p align>
     align - 
     
 LIst 
    --> Ordered List  <ol>
    --> Unordered List <ul>









function name(parameter){

  return 
  
  
  
}


<h1> hello world</h1>



















    
    
    
     
     
     
      
  