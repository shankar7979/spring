package com.shopping.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.shopping.dao.impl.RegisterDAOImpl;
import com.shopping.model.Register;


@Controller
@RequestMapping(value="/registration.htm")
public class RegisterController {
	
	@Autowired
	private RegisterDAOImpl registerDAO;
	
	@RequestMapping(method=RequestMethod.GET)
	public String showForm(ModelMap model){
		Register register = new Register();
		model.addAttribute("USER", register);
		return "registration";
	}

	@RequestMapping(method=RequestMethod.POST)
	public String processForm(@Valid @ModelAttribute(value="USER")Register register,BindingResult result){
		if(result.hasErrors()){
			return "registration";
		}else{
			registerDAO.registerUser(register);
			return "success";
		}		
	}
}

