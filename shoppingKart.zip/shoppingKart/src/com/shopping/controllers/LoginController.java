package com.shopping.controllers;



import javax.servlet.http.HttpSession;
import javax.validation.Valid;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.shopping.dao.impl.LoginDAOImpl;
import com.shopping.model.Login;

@Controller
@RequestMapping(value="/login.htm")
public class LoginController{
	
	public static final String ACCOUNT_ATTRIBUTE = "account";
    public static final String REQUESTED_URL = "REQUESTED_URL";
	
	@Autowired
	private LoginDAOImpl loginDAO;

	@RequestMapping(method=RequestMethod.GET)
	public String showForm(ModelMap model){
		Login login= new Login();
		model.addAttribute("LOGIN",login);
		return "login";
	}
	@RequestMapping(method=RequestMethod.POST)
	public String processForm(@Valid @ModelAttribute(value="LOGIN")Login login
			,BindingResult result,ModelMap model,HttpSession session){
		
		if(result.hasErrors()){
			return "login";
		}else{
			session.setAttribute(ACCOUNT_ATTRIBUTE, login);
	        session.removeAttribute(REQUESTED_URL); 
			System.out.println(login.getUserid());
			model.addAttribute("LOGIN",login);
			String w=loginDAO.authenticate(login);
			if(w.equals("admin"))
				return "adminPage";
			else if(w.equals("user"))
				return "redirect:/profile.htm";
			else 
			return "loginfailure";
		}
	}

}
