package com.shopping.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.shopping.dao.impl.CategoryDAOImpl;
import com.shopping.dao.impl.SubCategoryDAOImpl;
import com.shopping.model.Category;
import com.shopping.model.Login;
import com.shopping.model.Subcategory;



@Controller
public class ProfileController {
	Category category;
	List<Category> list=new ArrayList<Category>();
	List<Subcategory> list1=new ArrayList<Subcategory>();
	@Autowired
	private CategoryDAOImpl categoryDao;
	@Autowired
	private SubCategoryDAOImpl subCategoryDAO;
	
	@RequestMapping(value="/profile.htm",method=RequestMethod.GET)
	public String showForm(ModelMap model){
		category=new Category();
		Login login=new Login();
		model.addAttribute("LOGIN",login);
		Subcategory subcategory=new Subcategory();
		list=categoryDao.getCategoryList(category);
		model.addAttribute("CATEGORY",category);
		model.addAttribute("SUBCATEGORY",subcategory);
		model.addAttribute("categoryList",list);
		return "profile";
	}
	
	@RequestMapping(value="/category.htm" ,method=RequestMethod.POST)
	public String processForm(@RequestParam(value="cid")String cid,@Valid @ModelAttribute("CATEGORY")Category category,
			@ModelAttribute("SUBCATEGORY")Subcategory subcategory,BindingResult result,ModelMap model)
	{
		if(result.hasErrors()){
			return "profile";
		}
		else{
			list=categoryDao.getCategoryList(category);
			model.addAttribute("categoryList",list);
			list1=subCategoryDAO.populateSubcategory(cid);
			model.addAttribute("SUBCATEGORY",subcategory);
			model.addAttribute("subCategory",list1);
			return "subcategory";	
	}
	}
}