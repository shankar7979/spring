package com.shopping.dao;

import com.shopping.model.Register;

public interface RegisterDAO {
	public void registerUser(Register register);
}
