package com.shopping.dao;



import com.shopping.model.Login;

public interface LoginDAO {
	
	public String authenticate(Login login);
}
