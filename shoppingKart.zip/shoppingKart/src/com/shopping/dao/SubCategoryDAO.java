package com.shopping.dao;

import java.util.List;

import com.shopping.model.Subcategory;


public interface SubCategoryDAO {
	public List<Subcategory> populateSubcategory(String cid);
}
