package com.shopping.dao;

import java.util.List;

import com.shopping.model.Category;

public interface CategoryDAO {
	public List<Category> getCategoryList(Category category);
}
