package com.shopping.dao.impl;

import org.springframework.jdbc.core.JdbcTemplate;

import com.shopping.dao.RegisterDAO;
import com.shopping.model.Register;

public class RegisterDAOImpl implements RegisterDAO{
	private JdbcTemplate jdbcTemplate;
	 
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
	this.jdbcTemplate = jdbcTemplate;
	}
	
	@Override
	public void registerUser(Register register) {
		jdbcTemplate.update("insert into userinfo values(?,?,?,?,?,?,?,?,?)",register.getUserid(),register.getPassword(),register.getFname(),
				register.getLname(),register.getAddress1(),register.getAddress2(),register.getContactno(),register.getEmail(),register.getGender());
		jdbcTemplate.update("insert into login values(?,?,?)",register.getUserid(),register.getPassword(),"user");
	}

}
