package com.shopping.dao.impl;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

import com.shopping.dao.LoginDAO;
import com.shopping.model.Login;


public class LoginDAOImpl extends SimpleJdbcDaoSupport implements LoginDAO {
	
	/*private JdbcTemplate jdbcTemplate;
	 
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
	this.jdbcTemplate = jdbcTemplate;
	}
	*/
	@Override
	public String authenticate(Login login) {
		String sql="select role from login where userid=? AND password=?";
		Object roleObject = null;
		try {
			roleObject = getSimpleJdbcTemplate().queryForObject(sql,Object.class,login.getUserid(),login.getPassword());
		} catch (DataAccessException e) {
			System.out.println("No user found");
		}
		
		if(roleObject == null)
		{
			
			return "invalid user";
		}
		else
		{
			String role=(String)roleObject;			
			return role;
		}
	}

}
