package com.shopping.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.shopping.dao.CategoryDAO;
import com.shopping.model.Category;

public class CategoryDAOImpl implements CategoryDAO{
	private JdbcTemplate jdbcTemplate;
	 
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
	this.jdbcTemplate = jdbcTemplate;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Category> getCategoryList(Category category) {
		String sql="select * from category";
		RowMapper rowMapper=new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int arg1) throws SQLException {
				Category category= new Category(rs.getString("cid"),rs.getString("cname"));
				return category;
			}
			
		};
		List<Category> list=getJdbcTemplate().query(sql, rowMapper);
		return list;
		
	}
}
