package com.shopping.model;

public class Product {
	private String pid;
	private String scid;
	private String pname;
	private int initqty;
	private int remqty;
	private int price;
	private String specification;
	public Product() {
	}
	public Product(String pid,String scid,String pname,int initqty,int remqty,int price,String specification) {
			this.pid=pid;			
			this.scid=scid;
			this.pname=pname;		
			this.initqty=initqty;
			this.remqty=remqty;		
			this.price=price;
			this.specification=specification;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getPid() {
		return pid;
	}
	public void setScid(String scid) {
		this.scid = scid;
	}
	public String getScid() {
		return scid;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPname() {
		return pname;
	}
	public void setInitqty(int initqty) {
		this.initqty = initqty;
	}
	public int getInitqty() {
		return initqty;
	}
	public void setRemqty(int remqty) {
		this.remqty = remqty;
	}
	public int getRemqty() {
		return remqty;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getPrice() {
		return price;
	}
	public void setSpecification(String specification) {
		this.specification = specification;
	}
	public String getSpecification() {
		return specification;
	}
}
