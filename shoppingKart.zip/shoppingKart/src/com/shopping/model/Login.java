package com.shopping.model;


import org.hibernate.validator.constraints.NotEmpty;

public class Login {
	@NotEmpty(message="User Id cannot be empty")
	private String userid;
	@NotEmpty(message="Password cannot be empty")
	private String password;
	private String role;
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getUserid() {
		return userid;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPassword() {
		return password;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getRole() {
		return role;
	}
}
