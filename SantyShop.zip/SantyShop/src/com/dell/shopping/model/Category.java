package com.dell.shopping.model;



import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

public class Category {
	@NotEmpty(message="Please select a category")
	@NotNull (message="Please select a category")
	private String cid;
	private String cname;
	public Category() {
		// TODO Auto-generated constructor stub
	}
	public Category(String cid,String cname)
	{
		this.cid=cid;
		this.cname=cname;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public String getCid() {
		return cid;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getCname() {
		return cname;
	}
}
