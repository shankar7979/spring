package com.dell.shopping.model;

public class Subcategory {
	private String scid;
	private String cid;
	private String subcatname;
	
	public Subcategory() {
		// TODO Auto-generated constructor stub
	}
	
	public Subcategory(String scid,String cid,String subcatname) {
		this.scid=scid;
		this.cid=cid;
		this.subcatname=subcatname;
	}
	public void setScid(String scid) {
		this.scid = scid;
	}
	public String getScid() {
		return scid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public String getCid() {
		return cid;
	}
	public void setSubcatname(String subcatname) {
		this.subcatname = subcatname;
	}
	public String getSubcatname() {
		return subcatname;
	}
}
