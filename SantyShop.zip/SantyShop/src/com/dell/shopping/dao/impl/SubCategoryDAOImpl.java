package com.dell.shopping.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.dell.shopping.dao.SubCategoryDAO;
import com.dell.shopping.model.Subcategory;


public class SubCategoryDAOImpl implements SubCategoryDAO{
	private JdbcTemplate jdbcTemplate;
	 
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
	this.jdbcTemplate = jdbcTemplate;
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<Subcategory> populateSubcategory(String cid) {
		String sql="select * from subcategory where cid='"+cid+"'";
		RowMapper rowMapper=new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int arg1) throws SQLException {
				Subcategory subcategory= new Subcategory(rs.getString("scid"),rs.getString("cid"),rs.getString("subcatname"));
				return subcategory;
			}
			
		};
		List<Subcategory> list1=getJdbcTemplate().query(sql, rowMapper);
		return list1;
	}

}
