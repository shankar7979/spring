package com.dell.shopping.dao;

import com.dell.shopping.model.Register;

public interface RegisterDAO {
	public void registerUser(Register register);
}
