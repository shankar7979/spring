package com.dell.shopping.dao;

import java.util.List;

import com.dell.shopping.model.Subcategory;


public interface SubCategoryDAO {
	public List<Subcategory> populateSubcategory(String cid);
}
