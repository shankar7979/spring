package com.dell.shopping.dao;



import com.dell.shopping.model.Login;

public interface LoginDAO {
	
	public String authenticate(Login login);
}
