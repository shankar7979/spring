package com.dell.shopping.dao;

import java.util.List;

import com.dell.shopping.model.Product;

public interface ProductDAO {
		public List<Product> publishProduct(String scid);
}
