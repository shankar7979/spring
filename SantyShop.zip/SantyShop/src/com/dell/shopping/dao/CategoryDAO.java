package com.dell.shopping.dao;

import java.util.List;

import com.dell.shopping.model.Category;

public interface CategoryDAO {
	public List<Category> getCategoryList(Category category);
}
