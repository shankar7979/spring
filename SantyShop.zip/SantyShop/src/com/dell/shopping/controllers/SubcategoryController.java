package com.dell.shopping.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.dell.shopping.dao.impl.ProductDAOImpl;
import com.dell.shopping.model.Product;
import com.dell.shopping.model.Subcategory;

@Controller
public class SubcategoryController {
	List<Subcategory> list1=new ArrayList<Subcategory>();
	List<Product> productList=new ArrayList<Product>();
	@Autowired
	private ProductDAOImpl productDAO;
	
	@RequestMapping(value="/subcategory.htm",method=RequestMethod.GET)
	public String showForm(ModelMap model){
		Product product=new Product();
		Subcategory subcategory=new Subcategory();
		model.addAttribute("PRODUCT",product);
		model.addAttribute("SUBCATEGORY", subcategory);
		return "subcategory";
	}
	@RequestMapping(value="/subcategory.htm",method=RequestMethod.POST)
	public String processForm(@RequestParam(value="scid")String scid,@ModelAttribute("SUBCATEGORY")Subcategory subcategory,
			@ModelAttribute("PRODUCT")Product product,BindingResult result,ModelMap model)
	{
		if(result.hasErrors()){
			return "profile";
		}
		else{
			productList=productDAO.publishProduct(scid);
			/*for (Product product2 : productList) {
				System.out.println(product2.getPname());
			}*/
			model.addAttribute("PRODUCT",product);
			model.addAttribute("productList",productList);
			return "product";
		}
		
	}
	
}
