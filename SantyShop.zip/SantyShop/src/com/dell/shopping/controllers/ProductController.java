package com.dell.shopping.controllers;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import com.dell.shopping.model.Product;

@Controller
@RequestMapping("/product.htm")
public class ProductController {
	List<Product> productList=new ArrayList<Product>();
//	@Autowired
//	private ProductDAOImpl productDAO;
	@RequestMapping(method=RequestMethod.GET)
	public String showForm(ModelMap model){
		Product product=new Product();
		model.addAttribute("PRODUCT",product);
		return "product";
	}
	
}
