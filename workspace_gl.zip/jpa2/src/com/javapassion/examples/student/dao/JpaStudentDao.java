package com.javapassion.examples.student.dao;

import com.javapassion.examples.student.domain.Student;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import javax.persistence.*;


@Repository("studentDao")
public class JpaStudentDao implements StudentDao {
	
    @PersistenceContext
    private EntityManager entityManager;

    @Transactional
    public void store(Student student) {
        entityManager.merge(student);
    }

    @Transactional
    public void delete(Integer studentId) {
        Student student = entityManager.find(Student.class, studentId);
        entityManager.remove(student);
    }

    @Transactional(readOnly = true)
    public Student findById(Integer studentId) {
        return entityManager.find(Student.class, studentId);
    }

    @Transactional(readOnly = true)
    public List<Student> findAll() {
        Query query = entityManager.createQuery("from Student");
        return query.getResultList();
    }
}
