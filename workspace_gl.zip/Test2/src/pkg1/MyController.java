package pkg1;

import javax.servlet.http.HttpServletRequest;

import org.com.bean.Employee;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {

	@RequestMapping(value = "/a1.action", method = RequestMethod.GET)
	public String disp() {
		return "myform";
	}

/*	@RequestMapping(value = "/a1.action", method = RequestMethod.POST)
	public String disp1(HttpServletRequest request, ModelMap map) {

		Employee emp = new Employee();
		emp.setId(Integer.parseInt(request.getParameter("id")));
		emp.setName(request.getParameter("name"));
		map.put("emp", emp);
		return "result";
	}
*/	
	
	/*
	  @RequestMapping(value = "/a1.action", method = RequestMethod.POST) 
	  public	  String disp1(@RequestParam("id") String id,@RequestParam("name") String
	  name,ModelMap map ){ 
		  Employee emp = new Employee();
	  emp.setId(Integer.parseInt(id)); emp.setName(name); map.put("emp", emp);
	  return "result"; 
	  }
	 */

	@RequestMapping(value = "/a1.action", method = RequestMethod.POST)
	public ModelAndView disp1(@RequestParam("id") String id,
			@RequestParam("name") String name, ModelMap map) {
		/*
		  Employee emp = new Employee(); emp.setId(Integer.parseInt(id));
		  emp.setName(name); map.put("emp", emp); return "result";
		 */
		String msg;

		if (id.equals(""))
			msg = "<center><font color='red' size='5'>id is blank</font></center>";
		else if (name.equals(""))
			msg = "<center><font color='blue' size='5'>name is blank</font></center>";
		else
			msg = "<center><font color='blue' size='5'>Welcome mr." + name
					+ "<br>Your id is " + id + "</font></center>";

		return new ModelAndView("result1", "msg", msg);
	}
}
