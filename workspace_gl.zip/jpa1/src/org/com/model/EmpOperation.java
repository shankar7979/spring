package org.com.model;

public class EmpOperation {

}
