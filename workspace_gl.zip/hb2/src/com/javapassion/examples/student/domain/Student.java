package com.javapassion.examples.student.domain;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "STUDENT")
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Integer id;
    @Column(name = "NAME", length = 20, nullable = false)
    private String name;
    @Column(name = "BIRTHDAY")
    private Date birthday;
    @Column(name = "GRADE")
    private int grade;

    public Student() {
    }

    public Student(String name, Date birthday, int grade) {
        this.name = name;
        this.birthday = birthday;
        this.grade = grade;
    }

    public Date getBirthday() {
        return birthday;
    }

    public int getGrade() {
        return grade;
    }

    public Integer getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }


    public void setGrade(int grade) {
        this.grade = grade;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }
}
