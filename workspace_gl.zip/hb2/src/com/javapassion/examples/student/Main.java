package com.javapassion.examples.student;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.javapassion.examples.student.dao.StudentDao;
import com.javapassion.examples.student.domain.Student;

import java.util.GregorianCalendar;
import java.util.List;


public class Main {
    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");  

        StudentDao studentDao = (StudentDao) context.getBean("studentDao");

        Student student = new Student();
        student.setName("Sang Shin");
        student.setBirthday(new GregorianCalendar(2011, 2, 1).getTime());
        student.setGrade(8);
        studentDao.store(student);

        List<Student> students = studentDao.findAll();
        Integer studentId = students.get(0).getId();

        student = studentDao.findById(studentId);
		System.out.println("--->Student No: " + student.getId());
		System.out.println("--->Name: " + student.getName());
		System.out.println("--->Birthday: " + student.getBirthday());
		System.out.println("--->Grade: " + student.getGrade());

        studentDao.delete(studentId);
    }
}
