package com.javapassion.examples.student.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.javapassion.examples.student.domain.Student;

@Repository("studentDao")
public class HibernateStudentDao implements StudentDao {
	
	@Autowired
    private HibernateTemplate hibernateTemplate;

    public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
        this.hibernateTemplate = hibernateTemplate;
    }

    @Transactional
    public void store(Student student) {
        hibernateTemplate.saveOrUpdate(student);
    }

    @Transactional
    public void delete(Integer studentId) {
        Student student = (Student) hibernateTemplate.get(Student.class, studentId);
        hibernateTemplate.delete(student);
    }

    @Transactional(readOnly = true)
    public Student findById(Integer studentId) {
        return (Student) hibernateTemplate.get(Student.class, studentId);
    }

    @Transactional(readOnly = true)
    public List<Student> findAll() {
        return hibernateTemplate.find("from Student");
    }
}
