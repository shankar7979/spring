package com.javapassion.examples.student.dao;

import java.util.List;

import com.javapassion.examples.student.domain.Student;

public interface StudentDao {
    public void store(Student student);
    public void delete(Integer studentId);
    public Student findById(Integer studentId);
    public List<Student> findAll();
}
