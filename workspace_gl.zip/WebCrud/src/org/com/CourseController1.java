package org.com;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

@Controller
@RequestMapping
public class CourseController1 {
	@Autowired
	CourseDao dao;

	@RequestMapping(method = RequestMethod.GET, value = "/action1")
	public String disp1(ModelMap map1) {

		Course course1 = new Course();
		map1.addAttribute("course1", course1);
		return "CourseForm";
	}

	@RequestMapping(method = RequestMethod.POST, value = "/action2")
	public String disp1(@RequestParam("op") String op, HttpServletRequest req,
			@ModelAttribute("course1") Course course1, BindingResult result) {

		if (op.equals("add")) {
			System.out.println("add called");
			dao.add(course1);
			req.removeAttribute("msg");
			req.removeAttribute("operation");
			req.setAttribute("operation", op);
			req.setAttribute("msg", "Record added");
			return "CourseResult";
		}

		else if (op.equals("search")) {
			req.removeAttribute("operation");

			Course c1 = dao.findById(course1.getId());
			req.setAttribute("operation", op);
			System.out.println("search called   course is "+c1);
 
			if (c1 != null) {
				System.out.println("c1 not null");
				req.removeAttribute("msg");
				req.setAttribute("msg", "Id  found");
				req.setAttribute("c1", c1);
				return "CourseResult";
			} else {
				req.removeAttribute("msg");
				req.removeAttribute("err");
				req.setAttribute("err", "Id not found");
				return "CourseResult";
			}
		}

		else if (op.equals("show all")) {
			req.removeAttribute("list1");
			req.removeAttribute("operation");
			req.setAttribute("operation", op);
			req.setAttribute("list1", dao.findAll());
			return "CourseResult";
		}

		else if (op.equals("remove")) {
			dao.delete(course1.getId());
			req.removeAttribute("msg");
			req.removeAttribute("operation");
			req.setAttribute("operation", op);
			req.setAttribute("msg", "Record Deleted");
			return "CourseResult";
		} else
			return "CourseForm";
	}
}
