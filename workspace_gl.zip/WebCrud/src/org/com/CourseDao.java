package org.com;

import java.util.List;

public interface CourseDao {
    public void add(Course course);
    public void change(Course course);

    public void delete(Long courseId);

    public Course findById(Long courseId);

    public List<Course> findAll();
}
