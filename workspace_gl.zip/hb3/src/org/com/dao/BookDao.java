package org.com.dao;

import java.util.List;

import org.com.model.Book;

public interface BookDao {

	String addBook(Book book);

	List<Book> ShowAllBook();

	String removeBook(Book book);
	
	Book findBook(Book book);

}
