package org.com.dao;

import java.util.List;

import org.com.model.Book;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class BookDaoImpl extends HibernateDaoSupport implements BookDao {

	HibernateTemplate ht;
	Book book;

	@Override
	public String removeBook(Book book) {
		ht = getHibernateTemplate();
		Book b = (Book) ht.get(Book.class, book.getIsbn());
		if (b == null) {
			return "Book isbn not present";
		} else {
			ht.delete(book);
			return "Book removed with isbn "+book.getIsbn();
		}
	}

	
	@Override
	public String addBook(Book book) {
		ht = getHibernateTemplate();
		Book b = (Book) ht.get(Book.class, book.getIsbn());
		if (b != null) {
			return "Book isbn already exist";
		} else {
			ht.save(book);
			return "Book added";
		}
	}

	@Override
	public List<Book> ShowAllBook() {
		ht = getHibernateTemplate();
		List<Book> blist = (List<Book>) ht.find("from Book");
		return blist;
	}


	@Override
	public Book findBook(Book book) {
		ht = getHibernateTemplate();
		Book b = (Book) ht.get(Book.class, book.getIsbn());		
			return b;
		
	}

}
