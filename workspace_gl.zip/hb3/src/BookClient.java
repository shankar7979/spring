import java.util.List;
import java.util.Scanner;

import org.com.dao.BookDaoImpl;
import org.com.model.Book;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class BookClient {

	public static void main(String[] args) {

		BeanFactory fact = new ClassPathXmlApplicationContext("beans.xml");
		BookDaoImpl dao = (BookDaoImpl) fact.getBean("book1");

		Scanner sc = new Scanner(System.in);

		System.out.println("1.AddBook");
		System.out.println("2.ShowBook");
		System.out.println("3.RemoveBook");
		System.out.println("4.Search Book");

		int x = sc.nextInt();

		switch (x) {
		case 1:
			Book book = new Book();
			System.out.println("enter isbn");
			book.setIsbn(sc.nextInt());

			System.out.println("enter book name");
			book.setName(sc.next());

			System.out.println("enter author");
			book.setAuthor(sc.next());
			String res = dao.addBook(book);
			System.out.println(res);
			break;

		case 2:
			List<Book> blist = dao.ShowAllBook();
			System.out.println("\nAll books are ");
			for (Book book2 : blist) {
				System.out.println(book2.getIsbn() + "\t" + book2.getName()
						+ "\t" + book2.getAuthor());

			}

		case 3:
			Book book1 = new Book();
			System.out.println("enter isbn");
			book1.setIsbn(sc.nextInt());
			String res1 = dao.removeBook(book1);
			System.out.println(res1);
			break;			
		case 4:
			System.out.println("Enter isbn to find");
			int x1=sc.nextInt();
			Book b1=new Book();
			b1.setIsbn(x1);
			Book book2 =dao.findBook(b1);
			if(book2==null)
				System.out.println("isbn "+x1+" not present");
			else
				System.out.println(book2.getIsbn()+"\t"+book2.getName()+"\t"+book2.getAuthor());
			break;
			
		default:
			break;
		}

	}
}
