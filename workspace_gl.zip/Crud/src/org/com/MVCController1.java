package org.com;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class MVCController1 {

	@RequestMapping(value = "/hello", method = RequestMethod.GET)
	public String disp(ModelMap map) {

		map.addAttribute("student", new Student());
		return "form";
	}

	@RequestMapping(value = "/hello", method = RequestMethod.POST)
	public String disp(@ModelAttribute("student") @Valid  Student student,BindingResult result,ModelMap map) {

		if (result.hasErrors())
			return "form";

		else
			map.addAttribute("student", student);
		return "result";
	}

}
