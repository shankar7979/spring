package org.com;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

public class Student {

	//@Pattern(regexp = "//d+", message = "roll is not number")
	//@NotNull(message="roll is null")
	private int roll;
	
	//@NotEmpty(message = "Name is empty")
	//@Size(min=3,max=10)
	//@NotNull
	//@Pattern(regexp = "[a-z-A-Z]+\\s[a-z-A-Z]+", message = "Name has invalid characters")
	@NotEmpty
	private String name;

	//@Pattern(regexp = ".*[0-9]+.*", message = "marks must be numeric")
	@Digits(message="marks is not valid",integer=2,fraction=2)
	
	private float marks;

	public int getRoll() {
		return roll;
	}

	public void setRoll(int roll) {
		this.roll = roll;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getMarks() {
		return marks;
	}

	public void setMarks(float marks) {
		this.marks = marks;
	}
}
