package org.com;


import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

//@RestController
@Controller
public class CustomerController {

	
	@ModelAttribute("citylist")
	public List<String> addCity() {
		List<String> list1 = new ArrayList<String>();
		list1.add("Chennai");
		list1.add("madurai");
		list1.add("shivkashi");
		list1.add("rameshwaram");
		list1.add("ooty");
		return list1;
	}

	@ModelAttribute("statelist")
	public List<String> populateState() {

		List<String> sub_list = new ArrayList<String>();
		sub_list.add("none");
		sub_list.add("delhi");
		sub_list.add("bengal");
		sub_list.add("Haryana");
		sub_list.add("Kerala");
		return sub_list;
	}

	@ModelAttribute("genderlist")
	public List<String> populateGender() {

		List<String> sub_list = new ArrayList<String>();
		sub_list.add("male");
		sub_list.add("female");
		return sub_list;
	}
	
	@RequestMapping(value = "/hello", method = RequestMethod.GET)
	public String disp1(ModelMap map1) {
		Customer cst = new Customer();
		cst.setId(1001);
		cst.setName("ram kumar");
		cst.setSalary(20000);

		map1.addAttribute("cst", cst);
		//System.out.println("hello get called");
		return "form";
	}
	

	@RequestMapping(value = "/hello2", method = RequestMethod.POST)
	public String disp1(@RequestParam("op") String s ,  @ModelAttribute("cst")   @Valid Customer cst, BindingResult result, ModelMap map) {

		/*if(s.equals("ok"))
			System.out.println("1 clicked");
		if(s.equals("ok1"))
			System.out.println("2 clicked");
		
		
		return null;*/
		
		if (result.hasErrors()) {
			//System.out.println("hello post error  called");
			//map.addAttribute("cst", cst);
			return "form";
		} else {
			//System.out.println("hello post success  called");
			map.addAttribute("cst", cst);
			return "result";
		}
	}
}
