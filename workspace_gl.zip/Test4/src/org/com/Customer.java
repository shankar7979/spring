package org.com;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

public class Customer {

	// @Range(min = 1000, max = 10000)
	// @Digits(message="Numeric value required", integer=6, fraction = 0)
	// @Pattern(regexp = "[\\s]*[0-9]*[1-9]+",message="msg")
	private int id;

	@NotEmpty(message = "name is empty")
	@Size(max = 12, min = 3, message = "size between 3 to 12 chars")
	@Pattern(regexp = "[a-z-A-Z]+\\s[a-z-A-Z]+", message = "Name name has invalid characters")
	private String name;

	// @Range(min = 5000, max = 50000)
	// @Pattern(regexp=".*\\d.*")
	private float salary;

	@NotEmpty()
	@NotNull
	private String city[];
	@NotNull
	@NotEmpty()
	private String state;

	@NotEmpty()
	@NotNull
	private String gender;

	public String[] getCity() {
		return city;
	}

	public void setCity(String[] city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public float getSalary() {
		return salary;
	}

	public void setSalary(float salary) {
		this.salary = salary;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
