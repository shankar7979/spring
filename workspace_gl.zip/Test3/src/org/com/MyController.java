package org.com;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.com.model.Employee;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/hello")
public class MyController {

	// @RequestMapping("/hello.action")
	// @RequestMapping("/hello")
	@RequestMapping(method = RequestMethod.GET)
	public String show() {
		System.out.println("show called");
		//return "welcome";
		return "redirect:welcome";
	}

	@RequestMapping(value = "/welcome", method = RequestMethod.GET)
	public String show1() {
		System.out.println("show1 called");
		return "welcome1";
	}

	@RequestMapping("/empform")
	public String Emp_Show() {
		//return "redirect:EmpForm";
		return "EmpForm";
	}

	/*
	 * @RequestMapping("/empresult") public String Emp_Decide(HttpServletRequest
	 * request, ModelMap map) { int id =
	 * Integer.parseInt(request.getParameter("id")); String name =
	 * request.getParameter("name"); float salary =
	 * Float.parseFloat(request.getParameter("salary"));
	 * 
	 * Employee employee=new Employee();
	 * 
	 * employee.setId(id); employee.setName(name); employee.setSalary(salary);
	 * 
	 * request.setAttribute("emp", employee);
	 * 
	 * return "EmpSuccess"; }
	 */
	// using modelmap
	/*
	 * @RequestMapping("/empresult") public String Emp_Decide(HttpServletRequest
	 * request, ModelMap map) { int id =
	 * Integer.parseInt(request.getParameter("id")); String name =
	 * request.getParameter("name"); float salary =
	 * Float.parseFloat(request.getParameter("salary"));
	 * 
	 * Employee employee=new Employee();
	 * 
	 * employee.setId(id); employee.setName(name); employee.setSalary(salary);
	 * map.addAttribute("emp", employee);
	 * 
	 * List<String> list1=new ArrayList<String>(); list1.add("Delhi");
	 * list1.add("Noida"); list1.add("Gurgaon");
	 * 
	 * map.addAttribute("city", list1); //request.setAttribute("emp", employee);
	 * 
	 * return "EmpSuccess"; }
	 */

	ModelAndView view1;
	// using ModelandView

	@RequestMapping("/empresult")
	public ModelAndView Emp_Decide(HttpServletRequest request, ModelMap map) {
		int id = Integer.parseInt(request.getParameter("id"));
		String name = request.getParameter("name");
		String city = request.getParameter("city");
		
		float salary = Float.parseFloat(request.getParameter("salary"));

		Employee employee = new Employee();

		employee.setId(id);
		employee.setName(name);
		employee.setSalary(salary);
		employee.setCity(city);
		
		map.addAttribute("emp", employee);

		List<String> list1 = new ArrayList<String>();
		list1.add("Delhi");
		list1.add("Noida");
		list1.add("Gurgaon");

		map.addAttribute("city", list1);
		// request.setAttribute("emp", employee);
		// view1=new ModelAndView("EmpSuccess");
		// view1=new ModelAndView("EmpSuccess",map );
		view1 = new ModelAndView("EmpSuccess", "map", map);

		/*List<String> list2 = (List<String>) map.get("city");
		for (String string : list2) {
			System.out.println(string);
		}*/
		
		Map<String, String[]> map3 = request.getParameterMap();
		System.out.println("map3 size is ......" + map3.size());
		Set<String> s = map3.keySet();
		for (String string : s) {
			System.out.println("key " + string);
		}
		return view1;
	}
	
	
	@RequestMapping("/empresult1")
	public ModelAndView Emp_Decide1(@RequestParam("id") int id,@RequestParam("name") String name,@RequestParam("city") String city,@RequestParam("salary") float  salary, ModelMap map ) {
		Employee employee = new Employee();

		employee.setId(id);
		employee.setName(name);
		employee.setSalary(salary);
		employee.setCity(city);
		
		map.addAttribute("emp", employee);

		List<String> list1 = new ArrayList<String>();
		list1.add("Delhi");
		list1.add("Noida");
		list1.add("Gurgaon");

		map.addAttribute("city", list1);
		// request.setAttribute("emp", employee);
		// view1=new ModelAndView("EmpSuccess");
		// view1=new ModelAndView("EmpSuccess",map );
		view1 = new ModelAndView("EmpSuccess", "map", map);

		/*List<String> list2 = (List<String>) map.get("city");
		for (String string : list2) {
			System.out.println(string);
		}*/
		return view1;
	}	

	@RequestMapping("/searchEmp/{city1}")
	public String searchEmp(@PathVariable String city1, ModelMap map1) {
		System.out.println("city is  ............... ."+city1);

		List<String> list1 = new ArrayList<String>();
		list1.add("Delhi");
		list1.add("Noida");
		list1.add("Gurgaon");

	if(list1.contains(city1)){
		map1.addAttribute("city1",city1);
	}
	else 
		map1.addAttribute("city1","no city found");
		return "searchResult";
	}
}
