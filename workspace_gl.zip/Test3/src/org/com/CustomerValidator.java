package org.com;

import org.com.model.Customer;
import org.com.model.Employee;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

@Component
public class CustomerValidator implements Validator {

	@Override
	public boolean supports(Class<?> arg0) {
		return Customer.class.isAssignableFrom(arg0);
	}

	@Override
	public void validate(Object target, Errors errors) {
		
		//ValidationUtils.rejectIfEmptyOrWhitespace(errors, "id", "id.required", "id is blank");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "id", "id.required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "name.required", "name is blank");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "salary", "salary.required", "salary is blank");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "state", "state.required", "state is blank");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "gender", "gender.required", "gender is blank");

		Customer customer = (Customer) target;

		if (customer.getCity().length == 0) {
			errors.rejectValue("city", "city.required", "select city");
		}

		if (customer.getState().equals("none")) {
			errors.rejectValue("state", "state.required", "select state");
		}

	}

}
