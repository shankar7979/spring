package org.com;

import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.com.model.Customer;
import org.com.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class MyController2 {
	CustomerValidator customerValidator;

	@Autowired
	public MyController2(CustomerValidator customerValidator) {
		this.customerValidator = customerValidator;
	}

	@RequestMapping("/cstform")
	public String Cust_Show(Model model) {
		// phase 1
		Customer customer = new Customer();
		customer.setId(1001);
		customer.setName("mahesh kumar");
		customer.setSalary(20000.00f);

		model.addAttribute("cst", customer);
		return "CustomerForm";
	}

	@ModelAttribute("citylist")
	public List<String> addCity() {
		List<String> list1 = new ArrayList<String>();
		list1.add("Chennai");
		list1.add("madurai");
		list1.add("shivkashi");
		list1.add("rameshwaram");
		list1.add("ooty");
		return list1;
	}

	@ModelAttribute("statelist")
	public List<String> populateState() {

		List<String> sub_list = new ArrayList<String>();
		sub_list.add("none");
		sub_list.add("delhi");
		sub_list.add("bengal");
		sub_list.add("Haryana");
		sub_list.add("Kerala");
		return sub_list;
	}

	@ModelAttribute("genderlist")
	public List<String> populateGender() {

		List<String> sub_list = new ArrayList<String>();
		sub_list.add("male");
		sub_list.add("female");
		return sub_list;
	}

	@RequestMapping(value = "/cst1", method = RequestMethod.PUT)
	public void requsetbody(@RequestBody String body, Writer writer) throws IOException {
		writer.write("this is through body " + body);
	}

	@RequestMapping("/cstresult")
	public String Cust_Decide(@ModelAttribute("cst") Customer cst, Errors errors) {
		// pahse2
		customerValidator.validate(cst, errors);
		if (errors.hasErrors())
			return "CustomerForm";
		else
			return "CustomerSuccess";
	}
}