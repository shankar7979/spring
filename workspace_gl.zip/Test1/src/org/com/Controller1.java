package org.com;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import pack1.bean.Employee;

@RestController
// @Controller

public class Controller1 {

	@RequestMapping(value = "/hello.action", method = RequestMethod.GET)
	public String hello() {

		return "welcome";
	}

	/*@RequestMapping(value = "/hello.action", method = RequestMethod.POST)
	public String hello2(@RequestParam("id") int id, @RequestParam("name") String name, ModelMap model,
			HttpServletRequest request) {
		System.out.println("result called ...");
		Employee employee = new Employee();
		employee.setId(id);
		employee.setName(name);
		model.addAttribute("emp", employee);
		// request.setAttribute("emp", employee);
		return "result";
	}*/

	@RequestMapping(value = "/hello.action", method = RequestMethod.POST)
	public ModelAndView hello1(@RequestParam("id") int id, @RequestParam("name") String name, ModelMap model,
			HttpServletRequest request) {

		Employee employee = new Employee();
		employee.setId(id);
		employee.setName(name);
		model.addAttribute("emp", employee);

		return new ModelAndView("result", model);

	}

}
